import TermsAgreeFrame from "../components/TermsAgreeFrame";
import "./sign-up.css";

const SignUp = () => {
  return (
    <div className="sign-up2">
      <header className="rectangle-parent5">
        <div className="frame-child10" />
        <div className="div2">16:04</div>
        <div className="full-name-group-parent">
          <div className="full-name-group">
            <img
              className="vector-icon8"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
            <img
              className="vector-icon9"
              loading="lazy"
              alt=""
              src="/vector-1.svg"
            />
          </div>
          <img
            className="frame-child11"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <div className="new-account-label-wrapper">
        <div className="new-account-label">
          <img
            className="vector-icon10"
            loading="lazy"
            alt=""
            src="/vector-21.svg"
          />
          <div className="new-account">New Account</div>
        </div>
      </div>
      <main className="sign-up-inner">
        <form className="frame-form">
          <div className="full-name-parent">
            <div className="full-name1">Full name</div>
            <input
              className="frame-child12"
              placeholder="example@example.com"
              type="text"
            />
          </div>
          <div className="password-parent">
            <div className="password">{`Password `}</div>
            <button className="group-button">
              <div className="frame-child13" />
              <div className="div3">*************</div>
            </button>
          </div>
          <div className="email-parent">
            <div className="email1">Email</div>
            <input
              className="frame-child14"
              placeholder="example@example.com"
              type="text"
            />
          </div>
          <div className="mobile-number-parent">
            <div className="mobile-number">Mobile Number</div>
            <input
              className="frame-child15"
              placeholder="example@example.com"
              type="text"
            />
          </div>
          <div className="frame-wrapper1">
            <div className="date-of-birth-parent">
              <div className="date-of-birth1">Date of birth</div>
              <input
                className="frame-child16"
                placeholder="DD / MM /YYY"
                type="text"
              />
            </div>
          </div>
          <TermsAgreeFrame />
        </form>
      </main>
      <img
        className="vector-line-icon"
        loading="lazy"
        alt=""
        src="/vector-34.svg"
      />
      <div className="already-have-an-container">
        <span className="already-have-an">{`already have an account? `}</span>
        <span className="log-in">Log in</span>
      </div>
    </div>
  );
};

export default SignUp;
