import InfoFrame from "../components/InfoFrame";
import GroupComponent2 from "../components/GroupComponent2";
import GroupComponent1 from "../components/GroupComponent1";
import GroupComponent from "../components/GroupComponent";
import "./doctors.css";

const Doctors = () => {
  return (
    <div className="doctors">
      <header className="doctor-frame">
        <div className="doctor-frame-child" />
        <div className="main-f-r">16:04</div>
        <div className="vector-pair-parent">
          <div className="vector-pair">
            <img
              className="mask-group-f-r-a-m-e"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
            <img
              className="info-frame-icon"
              loading="lazy"
              alt=""
              src="/vector-1.svg"
            />
          </div>
          <img
            className="group-icon"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <main className="frame-group-info">
        <section className="solar-dermatology-f-r-a-m-e">
          <InfoFrame />
          <GroupComponent2 />
          <GroupComponent1 />
          <div className="rectangle-group">
            <div className="rectangle-div" />
            <img
              className="mask-group-icon"
              loading="lazy"
              alt=""
              src="/mask-group-31@2x.png"
            />
            <div className="frame-div">
              <div className="dr-sophia-martinez-phd-parent">
                <div className="dr-sophia-martinez">
                  Dr. Sophia Martinez, Ph.D.
                </div>
                <div className="cosmetic-bioengineering-parent">
                  <div className="cosmetic-bioengineering">
                    Cosmetic Bioengineering
                  </div>
                  <div className="frame-parent1">
                    <button className="rectangle-container">
                      <div className="frame-child1" />
                      <div className="info">Info</div>
                    </button>
                    <div className="frame-parent2">
                      <div className="group-div">
                        <div className="frame-child2" />
                        <img
                          className="vector-stroke-icon"
                          loading="lazy"
                          alt=""
                          src="/vector-32.svg"
                        />
                      </div>
                      <div className="rectangle-parent1">
                        <div className="frame-child3" />
                        <img
                          className="vector-icon2"
                          loading="lazy"
                          alt=""
                          src="/vector-41.svg"
                        />
                        <img
                          className="vector-icon3"
                          loading="lazy"
                          alt=""
                          src="/vector-51.svg"
                        />
                      </div>
                      <div className="rectangle-parent2">
                        <div className="frame-child4" />
                        <img
                          className="vector-icon4"
                          loading="lazy"
                          alt=""
                          src="/vector-6.svg"
                        />
                      </div>
                      <div className="rectangle-parent3">
                        <div className="frame-child5" />
                        <img
                          className="vector-158-stroke"
                          loading="lazy"
                          alt=""
                          src="/vector-158-stroke-11.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <GroupComponent />
        </section>
      </main>
      <div className="doctors-child" />
    </div>
  );
};

export default Doctors;
