import PasswordInput from "../components/PasswordInput";
import SignUpLink from "../components/SignUpLink";
import "./log-in1.css";

const LogIn1 = () => {
  return (
    <div className="log-in-2">
      <header className="frame-header">
        <div className="frame-child8" />
        <div className="div1">16:04</div>
        <div className="frame-parent4">
          <div className="vector-parent">
            <img
              className="vector-icon5"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
            <img
              className="vector-icon6"
              loading="lazy"
              alt=""
              src="/vector-1.svg"
            />
          </div>
          <img
            className="frame-child9"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <section className="log-in-2-inner">
        <div className="frame-parent5">
          <div className="vector-group">
            <img
              className="vector-icon7"
              loading="lazy"
              alt=""
              src="/vector-21.svg"
            />
            <div className="hello">Hello!</div>
          </div>
          <div className="welcome">Welcome</div>
        </div>
      </section>
      <section className="frame-section">
        <div className="email-or-mobile-number-parent">
          <div className="email-or-mobile">Email or Mobile Number</div>
          <input
            className="group-input"
            placeholder="example@example.com"
            type="text"
          />
        </div>
        <PasswordInput
          propPadding="0px 0px var(--padding-mid)"
          propMargin="unset"
          propPadding1="var(--padding-sm) var(--padding-6xl) var(--padding-xs) 0px"
        />
        <SignUpLink
          orSignUpWith="or"
          group99="/group-107.svg"
          propWidth="40px"
        />
      </section>
      <div className="new-user-call">
        <div className="dont-have-an-container1">
          <span className="dont-have-an1">{`Don’t have an account? `}</span>
          <span className="sign-up1">Sign Up</span>
        </div>
      </div>
    </div>
  );
};

export default LogIn1;
