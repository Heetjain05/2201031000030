import VectorVectorFrame from "../components/VectorVectorFrame";
import "./profile.css";

const Profile = () => {
  return (
    <div className="profile">
      <header className="rectangle-parent">
        <div className="frame-child" />
        <div className="div">16:04</div>
        <div className="vector-container-parent">
          <div className="vector-container">
            <img
              className="vector-icon"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
            <img
              className="vector-icon1"
              loading="lazy"
              alt=""
              src="/vector-1.svg"
            />
          </div>
          <img
            className="frame-item"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <main className="frame-parent">
        <section className="frame-group">
          <div className="name-frame-parent">
            <img
              className="name-frame-icon"
              loading="lazy"
              alt=""
              src="/vector-21.svg"
            />
            <div className="my-profile">my Profile</div>
          </div>
          <div className="frame-wrapper">
            <div className="frame-container">
              <img
                className="frame-inner"
                loading="lazy"
                alt=""
                src="/group-62@2x.png"
              />
              <div className="john-doe">John Doe</div>
            </div>
          </div>
        </section>
        <VectorVectorFrame />
      </main>
      <button className="empty-parent">
        <div className="empty-parent-child" />
        <img className="empty-parent-item" alt="" src="/group-49.svg" />
      </button>
    </div>
  );
};

export default Profile;
