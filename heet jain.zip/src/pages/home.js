import MainFrame from "../components/MainFrame";
import DaysOfWeek from "../components/DaysOfWeek";
import DaysFrameGroup from "../components/DaysFrameGroup";
import Weekdaygroup from "../components/Weekdaygroup";
import "./home.css";

const Home = () => {
  return (
    <div className="home">
      <MainFrame />
      <section className="rectangle-mask-group">
        <div className="am-text">
          <div className="am-text-child" />
          <DaysOfWeek />
          <DaysFrameGroup />
        </div>
      </section>
      <Weekdaygroup />
      <footer className="rectangle-mask">
        <div className="rectangle-mask-child" />
        <button className="parent-group">
          <div className="parent-group-child" />
          <img className="parent-group-item" alt="" src="/group-49.svg" />
        </button>
      </footer>
    </div>
  );
};

export default Home;
