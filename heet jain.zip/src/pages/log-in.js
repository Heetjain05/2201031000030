import LoginFrame from "../components/LoginFrame";
import "./log-in.css";

const LogIn = () => {
  return (
    <div className="log-in-1">
      <header className="parent-frame">
        <div className="parent-frame-child" />
        <div className="child-frame">16:04</div>
        <div className="child-frame1">
          <div className="vector-pair1">
            <img
              className="text-input-icon"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
            <img
              className="text-input-icon1"
              loading="lazy"
              alt=""
              src="/vector-1.svg"
            />
          </div>
          <img
            className="child-frame-child"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <LoginFrame />
      <div className="no-account-button">
        <div className="dont-have-an-container">
          <span className="dont-have-an">{`Don’t have an account? `}</span>
          <span className="sign-up">Sign Up</span>
        </div>
      </div>
    </div>
  );
};

export default LogIn;
