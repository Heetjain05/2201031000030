import PasswordInput from "./PasswordInput";
import SignUpLink from "./SignUpLink";
import "./login-frame.css";

const LoginFrame = () => {
  return (
    <section className="login-frame">
      <div className="parent-frame1">
        <button className="child-frame2">
          <img className="text-icon" alt="" src="/vector-21.svg" />
          <div className="log-in2">Log In</div>
        </button>
        <div className="text">
          <h1 className="welcome1">Welcome</h1>
          <div className="lorem-ipsum-dolor1">{`Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. `}</div>
        </div>
      </div>
      <div className="parent-frame2">
        <div className="child-frame3">
          <h2 className="email-or-mobile1">Email or Mobile Number</h2>
          <input
            className="child-frame-item"
            placeholder="example@example.com"
            type="text"
          />
        </div>
        <PasswordInput />
      </div>
      <SignUpLink orSignUpWith="or sign up with" group99="/group-99.svg" />
    </section>
  );
};

export default LoginFrame;
