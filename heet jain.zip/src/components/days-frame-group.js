import "./days-frame-group.css";

const DaysFrameGroup = () => {
  return (
    <div className="days-frame-group">
      <div className="days-frame-group-child" />
      <div className="today-and-wednesday">
        <div className="wednesday-today">11 Wednesday - Today</div>
        <div className="line-separator">
          <div className="dr-olivia-turner-m-d-text">
            <div className="am">9 am</div>
            <div className="vector-stroke-line">
              <div className="dermato-endocrinology-group" />
            </div>
          </div>
          <div className="frame-dr-olivia-turner-m-d">
            <div className="frames-a-m">
              <div className="am-a-m-p-m">
                <div className="am1">10 am</div>
                <div className="am2">11 am</div>
              </div>
            </div>
            <div className="group-doctors">
              <div className="group-doctors-child" />
              <div className="treatment-prevention-text">
                <div className="dr-olivia-turner">Dr. Olivia Turner, M.D.</div>
                <div className="frame-favorite-text">
                  <img
                    className="frame-favorite-text-child"
                    loading="lazy"
                    alt=""
                    src="/group-47.svg"
                  />
                  <img
                    className="frame-favorite-text-item"
                    loading="lazy"
                    alt=""
                    src="/group-10.svg"
                  />
                </div>
              </div>
              <div className="treatment-and-prevention">
                Treatment and prevention of skin and photodermatitis.
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="am-parent">
        <div className="am3">12 am</div>
        <div className="weekdayframe-wrapper">
          <div className="weekdayframe" />
        </div>
      </div>
    </div>
  );
};

export default DaysFrameGroup;
