import "./main-frame.css";

const MainFrame = () => {
  return (
    <section className="main-frame">
      <header className="rectangle-parent8">
        <div className="frame-child19" />
        <div className="outer-frame">16:04</div>
        <div className="text-area">
          <div className="vectors-row-parent">
            <img
              className="vectors-row-icon"
              loading="lazy"
              alt=""
              src="/vector.svg"
            />
            <img
              className="vector-pair-icon2"
              loading="lazy"
              alt=""
              src="/vector-1.svg"
            />
          </div>
          <img
            className="text-area-child"
            loading="lazy"
            alt=""
            src="/group-12.svg"
          />
        </div>
      </header>
      <div className="addon-frame">
        <div className="header-frame">
          <div className="subtitle-frame">
            <img
              className="mask-group-icon1"
              loading="lazy"
              alt=""
              src="/mask-group@2x.png"
            />
          </div>
          <div className="doctor-info-frame">
            <div className="name-field">
              <img
                className="hi-message-icon"
                loading="lazy"
                alt=""
                src="/vector-2.svg"
              />
            </div>
            <div className="doctors1">Doctors</div>
          </div>
        </div>
        <div className="circle-frames">
          <div className="welcome-frame">
            <div className="background-ellipse">
              <div className="hi-welcomeback">Hi, WelcomeBack</div>
              <div className="john-doe1">John Doe</div>
            </div>
            <div className="home-frame">
              <div className="group-frame">
                <div className="mask-group">
                  <div className="vector-ellipse" />
                  <div className="vector-ellipse1">
                    <img
                      className="ellipse-icon"
                      loading="lazy"
                      alt=""
                      src="/vector-3.svg"
                    />
                    <div className="frame" />
                  </div>
                </div>
              </div>
              <div className="group-frame1">
                <div className="group-frame-child" />
                <img
                  className="frame-icon"
                  loading="lazy"
                  alt=""
                  src="/vector-4.svg"
                />
              </div>
            </div>
          </div>
          <div className="favorite-text">
            <div className="group">
              <div className="vector-stroke">
                <img
                  className="vector-158-stroke1"
                  loading="lazy"
                  alt=""
                  src="/vector-158-stroke.svg"
                />
              </div>
              <div className="favorite">Favorite</div>
            </div>
            <div className="tue-wed-thu-sat">
              <div className="tue-wed-thu-sat-child" />
              <img
                className="tue-wed-thu-sat-item"
                loading="lazy"
                alt=""
                src="/group-108.svg"
              />
              <img
                className="frame-icon1"
                loading="lazy"
                alt=""
                src="/vector-5.svg"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MainFrame;
