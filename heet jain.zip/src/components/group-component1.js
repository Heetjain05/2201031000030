import "./group-component1.css";

const GroupComponent1 = () => {
  return (
    <div className="rectangle-parent25">
      <div className="frame-child36" />
      <img
        className="mask-group-icon6"
        loading="lazy"
        alt=""
        src="/mask-group-21@2x.png"
      />
      <div className="frame-wrapper4">
        <div className="frame-parent11">
          <div className="dr-olivia-turner-md-parent">
            <div className="dr-olivia-turner2">Dr. Olivia Turner, M.D.</div>
            <div className="dermato-endocrinology1">Dermato-Endocrinology</div>
          </div>
          <div className="vector-parent1">
            <button className="vector">
              <div className="vector-child" />
              <div className="info3">Info</div>
            </button>
            <div className="group1">
              <div className="rectangle-parent26">
                <div className="frame-child37" />
                <img
                  className="group-icon1"
                  loading="lazy"
                  alt=""
                  src="/vector-32.svg"
                />
              </div>
              <div className="rectangle-parent27">
                <div className="frame-child38" />
                <img
                  className="vector-group-icon"
                  loading="lazy"
                  alt=""
                  src="/vector-41.svg"
                />
                <img
                  className="vector-stroke-icon1"
                  loading="lazy"
                  alt=""
                  src="/vector-51.svg"
                />
              </div>
              <div className="rectangle-parent28">
                <div className="frame-child39" />
                <img
                  className="vector-icon15"
                  loading="lazy"
                  alt=""
                  src="/vector-6.svg"
                />
              </div>
              <div className="rectangle-parent29">
                <div className="frame-child40" />
                <img
                  className="vector-158-stroke7"
                  loading="lazy"
                  alt=""
                  src="/vector-158-stroke-11.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupComponent1;
