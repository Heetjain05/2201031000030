import { useMemo } from "react";
import "./password-input.css";

const PasswordInput = ({ propPadding, propMargin, propPadding1 }) => {
  const passwordInputStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const passwordStyle = useMemo(() => {
    return {
      margin: propMargin,
    };
  }, [propMargin]);

  const groupButtonStyle = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  return (
    <div className="password-input" style={passwordInputStyle}>
      <h2 className="password1" style={passwordStyle}>{`Password `}</h2>
      <div className="login-button">
        <button className="rectangle-parent35" style={groupButtonStyle}>
          <div className="frame-child46" />
          <div className="text-input">*************</div>
          <div className="vector-arrow">
            <img className="log-in-label" alt="" src="/vector-34.svg" />
          </div>
        </button>
        <div className="forget-pass-link">
          <div className="forget-password">Forget Password</div>
        </div>
      </div>
    </div>
  );
};

export default PasswordInput;
