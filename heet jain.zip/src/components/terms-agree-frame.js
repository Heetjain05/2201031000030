import "./terms-agree-frame.css";

const TermsAgreeFrame = () => {
  return (
    <div className="terms-agree-frame">
      <div className="terms-text-frame">
        <div className="by-continuing-you-container">
          <p className="by-continuing-you">{`By continuing, you agree to `}</p>
          <p className="terms-of-use-and-privacy-polic">
            <span className="span">{` `}</span>
            <span className="terms-of-use">Terms of Use</span>
            <span className="and">{` and `}</span>
            <span className="privacy-policy1">Privacy Policy.</span>
          </p>
        </div>
        <div className="password-group-frame">
          <button className="rectangle-parent37">
            <div className="frame-child48" />
            <div className="sign-up3">Sign Up</div>
          </button>
          <div className="login-link-text">
            <div className="or-sign-up1">or sign up with</div>
            <img
              className="login-link-text-child"
              loading="lazy"
              alt=""
              src="/group-99.svg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsAgreeFrame;
