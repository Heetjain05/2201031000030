import { useMemo } from "react";
import "./frame-component.css";

const FrameComponent = ({
  maskGroup,
  vector158Stroke,
  drAlexanderBennettPhD,
  dermatoGenetics,
  verticalGrouping,
  repeatedFrames,
  propWidth,
  propPadding,
  propMarginBottom,
  propAlignSelf,
  propWidth1,
  propFlex,
  propPadding1,
  propFlex1,
  propPadding2,
  onRectangle2Click,
}) => {
  const rectangleDivStyle = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const frameDivStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const drAlexanderBennettStyle = useMemo(() => {
    return {
      marginBottom: propMarginBottom,
    };
  }, [propMarginBottom]);

  const dermatoGeneticsStyle = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
    };
  }, [propAlignSelf]);

  const frameDiv1Style = useMemo(() => {
    return {
      width: propWidth1,
    };
  }, [propWidth1]);

  const doctorsGroupStyle = useMemo(() => {
    return {
      flex: propFlex,
      padding: propPadding1,
    };
  }, [propFlex, propPadding1]);

  const verticalGroupingStyle = useMemo(() => {
    return {
      flex: propFlex1,
    };
  }, [propFlex1]);

  const doctorsGroup1Style = useMemo(() => {
    return {
      padding: propPadding2,
    };
  }, [propPadding2]);

  return (
    <div className="rectangle-parent9">
      <div
        className="frame-child20"
        onClick={onRectangle2Click}
        style={rectangleDivStyle}
      />
      <img className="mask-group-icon2" loading="lazy" alt="" src={maskGroup} />
      <div className="frame-parent6">
        <div className="rectangle-parent10">
          <div className="frame-child21" />
          <img
            className="vector-158-stroke2"
            loading="lazy"
            alt=""
            src={vector158Stroke}
          />
        </div>
        <div className="frame-parent7">
          <div className="rectangle-parent11" style={frameDivStyle}>
            <div className="frame-child22" />
            <div className="dr-alexander-bennett-phd-wrapper">
              <div
                className="dr-alexander-bennett"
                style={drAlexanderBennettStyle}
              >
                {drAlexanderBennettPhD}
              </div>
            </div>
            <div className="dermato-genetics" style={dermatoGeneticsStyle}>
              {dermatoGenetics}
            </div>
          </div>
          <div className="frame-parent8">
            <div className="doctors-group-parent" style={frameDiv1Style}>
              <div className="doctors-group" style={doctorsGroupStyle}>
                <div className="doctors-group-child" />
                <img
                  className="doctors-group-item"
                  alt=""
                  src="/group-29.svg"
                />
                <div
                  className="vertical-grouping"
                  style={verticalGroupingStyle}
                >
                  {verticalGrouping}
                </div>
              </div>
              <div className="doctors-group1" style={doctorsGroup1Style}>
                <div className="doctors-group-inner" />
                <img
                  className="doctors-group-child1"
                  alt=""
                  src="/group-14.svg"
                />
                <div className="repeated-frames">{repeatedFrames}</div>
              </div>
            </div>
            <div className="rectangle-parent12">
              <div className="frame-child23" />
              <img className="vector-icon11" alt="" src="/vector-6.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent;
