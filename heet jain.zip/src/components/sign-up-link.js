import { useMemo } from "react";
import "./sign-up-link.css";

const SignUpLink = ({ orSignUpWith, group99, propWidth }) => {
  const groupIconStyle = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  return (
    <div className="sign-up-link">
      <div className="no-account-label">
        <button className="rectangle-parent36">
          <div className="frame-child47" />
          <div className="log-in1">Log In</div>
        </button>
        <div className="or-group">
          <div className="or-sign-up">{orSignUpWith}</div>
          <img
            className="or-group-child"
            loading="lazy"
            alt=""
            src={group99}
            style={groupIconStyle}
          />
        </div>
      </div>
    </div>
  );
};

export default SignUpLink;
