import "./days-of-week.css";

const DaysOfWeek = () => {
  return (
    <div className="days-of-week">
      <div className="doctors-and-days">
        <div className="doctors-and-days-child" />
        <div className="mon-fri-frame">
          <div className="mon-fri-frames">9</div>
          <div className="mon">Mon</div>
        </div>
      </div>
      <div className="doctors-and-days1">
        <div className="doctors-and-days-item" />
        <div className="div5">10</div>
        <div className="tue">Tue</div>
      </div>
      <div className="doctors-and-days2">
        <div className="doctors-and-days-inner" />
        <div className="div6">11</div>
        <div className="wed">Wed</div>
      </div>
      <div className="doctors-and-days3">
        <div className="doctors-and-days-child1" />
        <div className="div7">12</div>
        <div className="thu">thu</div>
      </div>
      <div className="doctors-and-days4">
        <div className="doctors-and-days-child2" />
        <div className="parent">
          <div className="div8">13</div>
          <div className="fri">fri</div>
        </div>
      </div>
      <div className="doctors-and-days5">
        <div className="doctors-and-days-child3" />
        <div className="div9">14</div>
        <div className="sat">sat</div>
      </div>
    </div>
  );
};

export default DaysOfWeek;
