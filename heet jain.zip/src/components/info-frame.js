import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./info-frame.css";

const InfoFrame = () => {
  const navigate = useNavigate();

  const onNameFramesIconClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="info-frame1">
      <div className="vector-stroke-frame">
        <div className="doctors-list">
          <img
            className="name-frames-icon"
            loading="lazy"
            alt=""
            src="/vector-21.svg"
            onClick={onNameFramesIconClick}
          />
        </div>
        <h2 className="doctors2">Doctors</h2>
        <div className="name-frames">
          <img
            className="name-frames-child"
            loading="lazy"
            alt=""
            src="/group-1081.svg"
          />
          <img
            className="name-frames-item"
            loading="lazy"
            alt=""
            src="/group-127.svg"
          />
        </div>
      </div>
      <div className="frame-with-info-parent">
        <div className="frame-with-info">
          <div className="combined-strokes">
            <div className="sort-by">Sort by</div>
          </div>
          <div className="vector-stroke-groups">
            <div className="vector-stroke-groups-child" />
            <div className="az">a→z</div>
          </div>
          <div className="vector-stroke-groups1">
            <div className="vector-stroke-groups-item" />
            <img
              className="vector-stroke-groups-inner"
              loading="lazy"
              alt=""
              src="/group-18.svg"
            />
          </div>
          <div className="vector-stroke-groups2">
            <div className="vector-stroke-groups-child1" />
            <img
              className="vector-158-stroke4"
              loading="lazy"
              alt=""
              src="/vector-158-stroke1.svg"
            />
          </div>
          <div className="vector-stroke-groups3">
            <div className="vector-stroke-groups-child2" />
            <img
              className="vector-stroke-groups-child3"
              alt=""
              src="/group-139.svg"
            />
          </div>
          <div className="vector-stroke-groups4">
            <div className="vector-stroke-groups-child4" />
            <img
              className="vector-stroke-groups-child5"
              loading="lazy"
              alt=""
              src="/group-140@2x.png"
            />
          </div>
        </div>
        <div className="rectangle-parent15">
          <div className="frame-child26" />
          <img
            className="mask-group-icon4"
            loading="lazy"
            alt=""
            src="/mask-group1@2x.png"
          />
          <div className="frame-wrapper2">
            <div className="dr-alexander-bennett-phd-parent">
              <div className="dr-alexander-bennett1">
                Dr. Alexander Bennett, Ph.D.
              </div>
              <div className="dr-bennett-label">
                <div className="dermato-genetics1">Dermato-Genetics</div>
                <div className="vector-stroke-group">
                  <button className="dermatoinfo-box">
                    <div className="dermatoinfo-box-child" />
                    <div className="info1">Info</div>
                  </button>
                  <div className="vector-details">
                    <div className="rectangle-parent16">
                      <div className="frame-child27" />
                      <img
                        className="vectors-arrangement-icon"
                        loading="lazy"
                        alt=""
                        src="/vector-32.svg"
                      />
                    </div>
                    <div className="rectangle-parent17">
                      <div className="frame-child28" />
                      <img
                        className="vector-stroke-set"
                        loading="lazy"
                        alt=""
                        src="/vector-41.svg"
                      />
                      <img
                        className="vector-stroke-set1"
                        loading="lazy"
                        alt=""
                        src="/vector-51.svg"
                      />
                    </div>
                    <div className="rectangle-parent18">
                      <div className="frame-child29" />
                      <img
                        className="vector-icon12"
                        loading="lazy"
                        alt=""
                        src="/vector-6.svg"
                      />
                    </div>
                    <div className="rectangle-parent19">
                      <div className="frame-child30" />
                      <img
                        className="vector-158-stroke5"
                        loading="lazy"
                        alt=""
                        src="/vector-158-stroke-11.svg"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InfoFrame;
