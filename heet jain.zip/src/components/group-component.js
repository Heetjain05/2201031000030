import "./group-component.css";

const GroupComponent = () => {
  return (
    <div className="rectangle-parent30">
      <div className="frame-child41" />
      <div className="dr-sophia-martinez1">Dr. Sophia Martinez, Ph.D.</div>
      <div className="cosmetic-bioengineering-group">
        <div className="cosmetic-bioengineering1">Cosmetic Bioengineering</div>
        <div className="stroke-vector-f-r-a-m-e">
          <img
            className="mask-group-icon7"
            alt=""
            src="/mask-group-31@2x.png"
          />
          <div className="rectangle-parent31">
            <div className="frame-child42" />
            <img className="vector-quartet-icon" alt="" src="/vector-32.svg" />
          </div>
          <div className="rectangle-parent32">
            <div className="frame-child43" />
            <img
              className="vector-158-stroke8"
              alt=""
              src="/vector-158-stroke-11.svg"
            />
          </div>
          <div className="rectangle-parent33">
            <div className="frame-child44" />
            <img className="rectangle-f-r-a-m-e" alt="" src="/vector-6.svg" />
          </div>
          <div className="rectangle-parent34">
            <div className="frame-child45" />
            <img className="vector-group-icon1" alt="" src="/vector-41.svg" />
          </div>
          <img className="vector-icon16" alt="" src="/vector-51.svg" />
          <div className="vector1" />
          <button className="group2">
            <div className="group-child" />
            <img className="group-item" alt="" src="/group-49.svg" />
          </button>
        </div>
      </div>
      <div className="info-wrapper">
        <div className="info4">Info</div>
      </div>
    </div>
  );
};

export default GroupComponent;
