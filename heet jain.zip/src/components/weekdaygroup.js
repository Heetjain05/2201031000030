import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent from "./FrameComponent";
import "./weekdaygroup.css";

const Weekdaygroup = () => {
  const navigate = useNavigate();

  const onRectangleClick = useCallback(() => {
    navigate("/doctors");
  }, [navigate]);

  const onRectangle2Click = useCallback(() => {
    navigate("/doctors");
  }, [navigate]);

  const onRectangle3Click = useCallback(() => {
    navigate("/doctors");
  }, [navigate]);

  const onRectangle4Click = useCallback(() => {
    navigate("/doctors");
  }, [navigate]);

  return (
    <section className="weekdaygroup">
      <div className="rectangle-parent13">
        <div className="frame-child24" onClick={onRectangle4Click} />
        <img
          className="mask-group-icon3"
          loading="lazy"
          alt=""
          src="/mask-group-1@2x.png"
        />
        <div className="datetext-parent">
          <div className="datetext">
            <div className="datetext-child" />
            <div className="amtext">
              <div className="dr-olivia-turner1">Dr. Olivia Turner, M.D.</div>
            </div>
            <div className="dermato-endocrinology">Dermato-Endocrinology</div>
          </div>
          <div className="doctorsgroup-parent">
            <div className="doctorsgroup">
              <div className="treatmentgroup">
                <div className="treatmentgroup-child" />
                <img
                  className="treatmentgroup-item"
                  alt=""
                  src="/group-18.svg"
                />
                <div className="preventiongroup">{`5 `}</div>
              </div>
              <div className="treatmentgroup1">
                <div className="treatmentgroup-inner" />
                <img
                  className="treatmentgroup-child1"
                  alt=""
                  src="/group-14.svg"
                />
                <div className="group-of-frames">60</div>
              </div>
            </div>
            <div className="frame-parent9">
              <div className="rectangle-parent14">
                <div className="frame-child25" />
                <img
                  className="child-vectors-icon"
                  alt=""
                  src="/vector-6.svg"
                />
              </div>
              <div className="stroke-vectors">
                <div className="stroke-vectors-child" />
                <img
                  className="vector-158-stroke3"
                  alt=""
                  src="/vector-158-stroke-1.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <FrameComponent
        maskGroup="/mask-group-2@2x.png"
        vector158Stroke="/vector-158-stroke-2.svg"
        drAlexanderBennettPhD="Dr. Alexander Bennett, Ph.D."
        dermatoGenetics="Dermato-Genetics"
        verticalGrouping="4,5 "
        repeatedFrames="40"
        onRectangle2Click={onRectangleClick}
      />
      <FrameComponent
        maskGroup="/mask-group-3@2x.png"
        vector158Stroke="/vector-158-stroke-2.svg"
        drAlexanderBennettPhD="Dr. Sophia Martinez, Ph.D."
        dermatoGenetics="Cosmetic Bioengineering"
        verticalGrouping="5 "
        repeatedFrames="150"
        propWidth="calc(100% - 2px)"
        propPadding="var(--padding-4xs) var(--padding-smi) var(--padding-9xs) var(--padding-sm)"
        propMarginBottom="unset"
        propAlignSelf="stretch"
        propWidth1="90px"
        propFlex="1"
        propPadding1="var(--padding-8xs) var(--padding-10xs) var(--padding-12xs) var(--padding-7xs)"
        propFlex1="1"
        propPadding2="var(--padding-8xs) var(--padding-6xs) var(--padding-12xs) var(--padding-8xs)"
        onRectangle2Click={onRectangle2Click}
      />
      <FrameComponent
        maskGroup="/mask-group-4@2x.png"
        vector158Stroke="/vector-158-stroke-1.svg"
        drAlexanderBennettPhD="Dr. Michael Davidson, M.D."
        dermatoGenetics="Nano-Dermatology"
        verticalGrouping="4,8"
        repeatedFrames="90"
        propWidth="calc(100% - 2px)"
        propPadding="var(--padding-4xs) var(--padding-mid) var(--padding-9xs) var(--padding-sm)"
        propMarginBottom="-1px"
        propAlignSelf="unset"
        propWidth1="unset"
        propFlex="unset"
        propPadding1="var(--padding-8xs) var(--padding-4xs) var(--padding-12xs) var(--padding-7xs)"
        propFlex1="unset"
        propPadding2="var(--padding-8xs) var(--padding-3xs) var(--padding-12xs) var(--padding-8xs)"
        onRectangle2Click={onRectangle3Click}
      />
    </section>
  );
};

export default Weekdaygroup;
