import "./vector-vector-frame.css";

const VectorVectorFrame = () => {
  return (
    <section className="vector-vector-frame">
      <img
        className="vector-pair-frame"
        loading="lazy"
        alt=""
        src="/vector-31.svg"
      />
      <img
        className="vector-pair-frame1"
        loading="lazy"
        alt=""
        src="/vector-31.svg"
      />
      <div className="frame-parent10">
        <div className="parent-of-favorites-parent">
          <div className="parent-of-favorites">
            <img
              className="parent-of-favorites-child"
              loading="lazy"
              alt=""
              src="/group-30.svg"
            />
            <div className="profile-wrapper">
              <div className="profile2">Profile</div>
            </div>
          </div>
          <div className="parent-of-favorites1">
            <img
              className="parent-of-favorites-item"
              loading="lazy"
              alt=""
              src="/group-31.svg"
            />
            <div className="favorite-wrapper">
              <div className="favorite1">Favorite</div>
            </div>
          </div>
          <div className="parent-of-favorites2">
            <img
              className="parent-of-favorites-inner"
              loading="lazy"
              alt=""
              src="/group-32.svg"
            />
            <div className="payment-method-wrapper">
              <div className="payment-method">Payment Method</div>
            </div>
          </div>
          <div className="parent-of-favorites3">
            <img
              className="parent-of-favorites-child1"
              loading="lazy"
              alt=""
              src="/group-33.svg"
            />
            <div className="privacy-policy-wrapper">
              <div className="privacy-policy">Privacy Policy</div>
            </div>
          </div>
          <div className="parent-of-favorites4">
            <img
              className="parent-of-favorites-child2"
              loading="lazy"
              alt=""
              src="/group-34.svg"
            />
            <div className="settings-wrapper">
              <div className="settings">Settings</div>
            </div>
          </div>
          <div className="parent-of-favorites5">
            <img
              className="parent-of-favorites-child3"
              loading="lazy"
              alt=""
              src="/group-35.svg"
            />
            <div className="help-wrapper">
              <div className="help">Help</div>
            </div>
          </div>
          <div className="parent-of-favorites6">
            <img
              className="parent-of-favorites-child4"
              loading="lazy"
              alt=""
              src="/group-36.svg"
            />
            <div className="logout-wrapper">
              <div className="logout">Logout</div>
            </div>
          </div>
        </div>
        <div className="multi-vector-container">
          <div className="containing-frame">
            <img
              className="quad-vector-set"
              loading="lazy"
              alt=""
              src="/vector-31.svg"
            />
            <img
              className="quad-vector-set1"
              loading="lazy"
              alt=""
              src="/vector-31.svg"
            />
            <img
              className="quad-vector-set2"
              loading="lazy"
              alt=""
              src="/vector-7.svg"
            />
            <img
              className="quad-vector-set3"
              loading="lazy"
              alt=""
              src="/vector-7.svg"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default VectorVectorFrame;
