import "./group-component2.css";

const GroupComponent2 = () => {
  return (
    <div className="rectangle-parent20">
      <div className="frame-child31" />
      <img
        className="mask-group-icon5"
        loading="lazy"
        alt=""
        src="/mask-group-11@2x.png"
      />
      <div className="frame-wrapper3">
        <div className="dr-michael-davidson-md-parent">
          <div className="dr-michael-davidson">Dr. Michael Davidson, M.D.</div>
          <div className="solar-dermatology">Solar Dermatology</div>
          <div className="info-frame-parent">
            <div className="info-frame2">
              <div className="info-frame-child" />
              <div className="info2">Info</div>
            </div>
            <div className="ato-z-label">
              <div className="rectangle-parent21">
                <div className="frame-child32" />
                <img
                  className="vector-stroke-group1"
                  alt=""
                  src="/vector-32.svg"
                />
              </div>
              <div className="rectangle-parent22">
                <div className="frame-child33" />
                <img
                  className="vector-group-vector"
                  alt=""
                  src="/vector-41.svg"
                />
                <img className="vector-icon13" alt="" src="/vector-51.svg" />
              </div>
              <div className="rectangle-parent23">
                <div className="frame-child34" />
                <img className="vector-icon14" alt="" src="/vector-6.svg" />
              </div>
              <div className="rectangle-parent24">
                <div className="frame-child35" />
                <img
                  className="vector-158-stroke6"
                  alt=""
                  src="/vector-158-stroke-11.svg"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GroupComponent2;
